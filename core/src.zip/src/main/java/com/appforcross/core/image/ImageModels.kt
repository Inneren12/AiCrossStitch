// Hash b3ec016af15823f7d467bd3c80aeaa52
package com.appforcross.core.image

data class DecodedImage(val width: Int, val height: Int, val argb: IntArray)

data class Raster(val width: Int, val height: Int, val argb: IntArray)
