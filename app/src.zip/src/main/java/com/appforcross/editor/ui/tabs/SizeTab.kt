//Hash 33324763b75c5ca1f0106a4d94bac580
package com.appforcross.editor.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import com.appforcross.editor.EditorViewModel
import com.appforcross.editor.model.*
import com.appforcross.editor.ui.components.ApplyBar
import com.appforcross.editor.ui.components.Section

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SizeTab(vm: EditorViewModel) {
    val st by vm.state.collectAsState()
    val s = st.size

    Column(Modifier.fillMaxSize()) {
        Section("Размер") {
            if (st.isBusy) {
                // Индикатор процесса пересчёта размеров (indeterminate)
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = s.unit == UnitMode.ST_PER_INCH,
                    onClick = { vm.updateSize { it.copy(unit = UnitMode.ST_PER_INCH) } },
                    label = { Text("ст/дюйм") }
                )
                FilterChip(
                    selected = s.unit == UnitMode.ST_PER_CM,
                    onClick = { vm.updateSize { it.copy(unit = UnitMode.ST_PER_CM) } },
                    label = { Text("ст/см") }
                )
            }

            Spacer(Modifier.height(12.dp))

            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    readOnly = true,
                    value = densityLabel(s.presetDensity, s.unit),
                    onValueChange = {},
                    label = { Text("Предустановка") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    listOf(11f, 12f, 14f, 16f, 18f).forEach { d ->
                        DropdownMenuItem(text = { Text(densityLabel(d, s.unit)) }, onClick = {
                            vm.updateSize { it.copy(presetDensity = d) }
                            expanded = false
                        })
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SegButton("По ширине", selected = s.pick == SizePick.BY_WIDTH) {
                    vm.updateSize { it.copy(pick = SizePick.BY_WIDTH) }
                }
                SegButton("По высоте", selected = s.pick == SizePick.BY_HEIGHT) {
                    vm.updateSize { it.copy(pick = SizePick.BY_HEIGHT) }
                }
                SegButton("По DPI", selected = s.pick == SizePick.BY_DPI) {
                    vm.updateSize { it.copy(pick = SizePick.BY_DPI) }
                }
            }

            Spacer(Modifier.height(12.dp))

            when (s.pick) {
                SizePick.BY_WIDTH -> {
                    NumberField(
                        label = "Ширина (крестики)",
                        value = s.widthStitches.toString(),
                        onValue = { v -> v.toIntOrNull()?.let { k -> vm.updateSize { s0 -> s0.copy(widthStitches = itBound(k)) } }
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    ReadOnlyLine("Высота (крестики)", estimateHeight(s, st.aspect).toString())
                }
                SizePick.BY_HEIGHT -> {
                    NumberField(
                        label = "Высота (крестики)",
                        value = s.heightStitches.toString(),
                        onValue = { v -> v.toIntOrNull()?.let { k -> vm.updateSize { s0 -> s0.copy(heightStitches = itBound(k)) } }
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    ReadOnlyLine("Ширина (крестики)", estimateWidth(s, st.aspect).toString())
                }
                SizePick.BY_DPI -> {
                    NumberField(
                        label = "Плотность (ст/дюйм или ст/см)",
                        value = s.presetDensity.toString(),
                        onValue = { v -> v.toFloatOrNull()?.let { k -> vm.updateSize { s0 -> s0.copy(presetDensity = k) } }
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    ReadOnlyLine("Размер в дюймах/см (расчёт)", calcPhysicalSizeText(s, st.aspect))
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = s.keepAspect, onCheckedChange = { c ->
                    vm.updateSize { it.copy(keepAspect = c) }
                })
                Text("Сохранять пропорции")
            }

            Spacer(Modifier.height(8.dp))
            NumberField(
                label = "Страниц (цель)",
                value = s.pagesTarget.toString(),
                onValue = { v -> v.toIntOrNull()?.let { k -> vm.updateSize { s0 -> s0.copy(pagesTarget = k.coerceAtLeast(1)) } }
                }
            )

            Spacer(Modifier.height(12.dp))
            Text(physicalSummaryLine(s, st.aspect), style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.weight(1f))
        ApplyBar(enabled = st.sourceImage != null && !st.isBusy) {
            vm.applySize()
        }
    }
}

private fun itBound(it: Int) = it.coerceIn(1, 50000)

@Composable private fun SegButton(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(text) })
}

@Composable private fun NumberField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable private fun ReadOnlyLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

private fun densityLabel(d: Float, unit: UnitMode) =
    if (unit == UnitMode.ST_PER_INCH) "${d.toInt()} ст/дюйм" else String.format("%.2f ст/см", d)

private fun estimateHeight(s: SizeState, aspect: Float): Int =
    if (!s.keepAspect) s.heightStitches else (s.widthStitches / aspect).toInt().coerceAtLeast(1)

private fun estimateWidth(s: SizeState, aspect: Float): Int =
    if (!s.keepAspect) s.widthStitches else (s.heightStitches * aspect).toInt().coerceAtLeast(1)

private fun physicalSummaryLine(s: SizeState, aspect: Float): String {
    val w = if (s.pick == SizePick.BY_HEIGHT) estimateWidth(s, aspect) else s.widthStitches
    val h = if (s.pick == SizePick.BY_WIDTH) estimateHeight(s, aspect) else s.heightStitches
    val wIn = w / maxOf(1f, s.presetDensity)
    val hIn = h / maxOf(1f, s.presetDensity)
    val inches = String.format("ширина %.2f\" (%.2f см), высота %.2f\" (%.2f см)", wIn, wIn * 2.54f, hIn, hIn * 2.54f)
    return "При плотности ~" + String.format("%.2f", s.presetDensity) + ": " + inches
}

private fun calcPhysicalSizeText(s: SizeState, aspect: Float): String {
    val w = s.widthStitches
    val h = if (s.keepAspect) (w / aspect) else s.heightStitches
    val wIn = w.toFloat() / maxOf(1f, s.presetDensity)
    val hIn = h.toFloat() / maxOf(1f, s.presetDensity)
    return String.format("%.2f × %.2f", wIn, hIn)
}