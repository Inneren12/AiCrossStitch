//Hash 7ef703ae7a8b6289e7c99078aafd0dcb
package com.appforcross.editor.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.appforcross.editor.EditorViewModel
import com.appforcross.editor.model.DenoiseLevel
import com.appforcross.editor.ui.components.ApplyBar
import com.appforcross.editor.ui.components.Section
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreprocessTab(vm: EditorViewModel) {
    val st by vm.state.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

        Section("Яркость / Контраст") {
            Text("Яркость: ${st.preprocess.brightnessPct} %")
            Slider(
                value = st.preprocess.brightnessPct.toFloat(),
                onValueChange = { v -> vm.updatePreprocess { it.copy(brightnessPct = v.toInt()) } },
                valueRange = -100f..100f
            )
            Spacer(Modifier.height(8.dp))
            Text("Контраст: ${st.preprocess.contrastPct} %")
            Slider(
                value = st.preprocess.contrastPct.toFloat(),
                onValueChange = { v -> vm.updatePreprocess { it.copy(contrastPct = v.toInt()) } },
                valueRange = -100f..100f
            )
        }

        Section("Гамма") {
            Text("γ = " + String.format("%.2f", st.preprocess.gamma))
            Slider(
                value = st.preprocess.gamma,
                onValueChange = { v -> vm.updatePreprocess { it.copy(gamma = v) } },
                valueRange = 0.1f..3.0f
            )

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(
                    checked = st.preprocess.autoLevels,
                    onCheckedChange = { c -> vm.updatePreprocess { it.copy(autoLevels = c) } }
                )
                Text("Автоуровни (растяжка гистограммы)")
            }
        }

        Section("Шумоподавление") {
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(
                    readOnly = true,
                    value = when (st.preprocess.denoise) {
                        DenoiseLevel.NONE -> "Нет"
                        DenoiseLevel.LOW -> "Слабое"
                        DenoiseLevel.MEDIUM -> "Среднее"
                        DenoiseLevel.HIGH -> "Сильное"
                    },
                    onValueChange = {},
                    label = { Text("Denoise") },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(text = { Text("Нет") }, onClick = {
                        vm.updatePreprocess { it.copy(denoise = DenoiseLevel.NONE) }; expanded = false
                    })
                    DropdownMenuItem(text = { Text("Слабое") }, onClick = {
                        vm.updatePreprocess { it.copy(denoise = DenoiseLevel.LOW) }; expanded = false
                    })
                    DropdownMenuItem(text = { Text("Среднее") }, onClick = {
                        vm.updatePreprocess { it.copy(denoise = DenoiseLevel.MEDIUM) }; expanded = false
                    })
                    DropdownMenuItem(text = { Text("Сильное") }, onClick = {
                        vm.updatePreprocess { it.copy(denoise = DenoiseLevel.HIGH) }; expanded = false
                    })
                }
            }
        }

        Section("Тональная компрессия (жёсткий контраст → мягче)") {
            Text(String.format("%.2f", st.preprocess.tonalCompression))
            Slider(
                value = st.preprocess.tonalCompression,
                onValueChange = { v -> vm.updatePreprocess { it.copy(tonalCompression = v) } },
                valueRange = 0f..1f
            )
            Spacer(Modifier.height(8.dp))
            Text("Все параметры применяются ДО ресемплинга и квантования.")
        }

        Spacer(Modifier.weight(1f))
        ApplyBar(enabled = st.sourceImage != null && !st.isBusy) {
            vm.applyPreprocess()
        }
    }
}