//Hash 66e4116707ddae9e8a0e7527daa22ed2
package com.appforcross.editor.ui.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.appforcross.editor.EditorViewModel
import com.appforcross.editor.model.*
import com.appforcross.editor.ui.components.ApplyBar
import com.appforcross.editor.ui.components.Section

@Composable
fun OptionsTab(vm: EditorViewModel) {
    val st by vm.state.collectAsState()
    val o = st.options

    Column(Modifier.fillMaxSize()) {

        Section("Палитра") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Seg(text = "DMC (как есть)", selected = o.useDmcAsIs) {
                    vm.updateOptions { it.copy(useDmcAsIs = true) }
                }
                Seg(text = "Адаптивная → DMC", selected = !o.useDmcAsIs) {
                    vm.updateOptions { it.copy(useDmcAsIs = false) }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("Слияние близких цветов (ΔE): " + String.format("%.2f", o.mergeDeltaE))
            Slider(
                value = o.mergeDeltaE,
                onValueChange = { v -> vm.updateOptions { it.copy(mergeDeltaE = v) } },
                valueRange = 0f..20f
            )
        }

        Section("Дизеринг (умный FS)") {
            Text("Сила: ${o.fsStrengthPct} %")
            Slider(
                value = o.fsStrengthPct.toFloat(),
                onValueChange = { v -> vm.updateOptions { it.copy(fsStrengthPct = v.toInt()) } },
                valueRange = 0f..100f
            )
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(checked = o.cleanSingles, onCheckedChange = { c ->
                    vm.updateOptions { it.copy(cleanSingles = c) }
                })
                Text("Подчищать одиночные крестики")
            }
        }

        Section("Ресэмплинг") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Seg(text = "Усреднение по клетке", selected = o.resampling == ResamplingMode.AVERAGE_PER_CELL) {
                    vm.updateOptions { it.copy(resampling = ResamplingMode.AVERAGE_PER_CELL) }
                }
                Seg(text = "Простой (быстрее)", selected = o.resampling == ResamplingMode.SIMPLE_FAST) {
                    vm.updateOptions { it.copy(resampling = ResamplingMode.SIMPLE_FAST) }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("Лёгкое размытие перед ресэмплом σ = " + String.format("%.2f", o.preBlurSigmaPx) + " px")
            Slider(
                value = o.preBlurSigmaPx,
                onValueChange = { v -> vm.updateOptions { it.copy(preBlurSigmaPx = v) } },
                valueRange = 0f..5f
            )
            Text("Рекомендуется: «Усреднение», FS ~50%, подчистка одиночных.")
        }

        Spacer(Modifier.weight(1f))
        ApplyBar(enabled = st.previewImage != null && !st.isBusy) {
            vm.applyOptions()
        }
    }
}

@Composable private fun Seg(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected = selected, onClick = onClick, label = { Text(text) })
}