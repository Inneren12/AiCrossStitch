// Hash 3b7a406bdac60532aedb1285442c492c
package com.appforcross.editor

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.appforcross.editor.engine.EditorEngine
import com.appforcross.editor.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.ImageBitmap
import com.appforcross.core.palette.PaletteMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class EditorViewModel(private val engine: EditorEngine) : ViewModel() {

    private val _state = MutableStateFlow(EditorState())
    val state = _state.asStateFlow()

    // --- Пайплайн: зафиксированные изображения по стадиям ---
    private var appliedImport: ImageBitmap? = null
    private var appliedPreprocess: ImageBitmap? = null
    private var appliedSize: ImageBitmap? = null
    private var appliedPalette: ImageBitmap? = null
    private var appliedOptions: ImageBitmap? = null

    // dirty-флаги стадий (ниже по графу)
    private var dirtySize = false
    private var dirtyPalette = false
    private var dirtyOptions = false

    // Хранилище палитр: нужно для computeThreadStatsAgainstPalette
    private var paletteRepository: com.appforcross.core.palette.PaletteRepository? = null
    fun setPaletteRepository(repo: com.appforcross.core.palette.PaletteRepository) {
        paletteRepository = repo
    }

    // Активная палитра — реактивно (StateFlow), без изменения EditorState
    private val _activePaletteId = MutableStateFlow("")
    val activePaletteId: kotlinx.coroutines.flow.StateFlow<String> = _activePaletteId.asStateFlow()
    fun getPalettes(): List<PaletteMeta> = paletteRepository?.list().orEmpty()
    fun getActivePaletteId(): String {
        val cached = _activePaletteId.value
        if (cached.isNotEmpty()) return cached
        val id = getPalettes().firstOrNull()?.id ?: "dmc"
        _activePaletteId.value = id
        return id
    }
    fun setActivePalette(id: String) { _activePaletteId.value = id }

    // Модель нитки для UI (локально, без правок EditorState)
    data class ThreadItem(
        val code: String,
        val name: String,
        val argb: Int,
        val percent: Int,
        val count: Int
    )
    private val _threads = MutableStateFlow<List<ThreadItem>>(emptyList())
    val threads: kotlinx.coroutines.flow.StateFlow<List<ThreadItem>> = _threads.asStateFlow()


       // --- Символы ниток: draft (редактирование) и применённые к предпросмотру ---
       private val symbolSet: CharArray = charArrayOf(
           '●','○','■','□','▲','△','◆','◇','★','☆','✚','✖','✳','◼','◻','✦','✧',
           'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
           'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
           '0','1','2','3','4','5','6','7','8','9'
       )
    private val _symbolDraft = MutableStateFlow<Map<String, Char>>(emptyMap())
    val symbolDraft = _symbolDraft.asStateFlow()
    private val _symbolsPreview = MutableStateFlow<Map<String, Char>>(emptyMap())
    val symbolsPreview = _symbolsPreview.asStateFlow()
    fun symbolFor(code: String): Char? = _symbolDraft.value[code] ?: _symbolsPreview.value[code]
    fun setSymbol(code: String, ch: Char) {
        val cur = _symbolDraft.value.toMutableMap()
        // уникальность: если символ занят другим цветом — перекинем тот цвет на свободный
        val conflict = cur.entries.firstOrNull { it.value == ch && it.key != code }?.key
        if (conflict != null) {
            val used = cur.values.toMutableSet()
            used.add(ch)
            cur[conflict] = pickFreeSymbol(used)
        }
        cur[code] = ch
        _symbolDraft.value = cur
    }
    private fun pickFreeSymbol(used: MutableSet<Char>): Char {
        for (c in symbolSet) if (used.add(c)) return c
        return '?'
    }
    private fun autoAssignSymbolsForThreads(list: List<ThreadItem>) {
        val cur = _symbolDraft.value.toMutableMap()
        val used = cur.values.toMutableSet()
        list.forEach { item ->
            if (!cur.containsKey(item.code)) {
                cur[item.code] = pickFreeSymbol(used)
                            }
        }
        _symbolDraft.value = cur
    }
    fun hasSymbolsFor(codes: List<String>): Boolean {
        val m = if (_symbolDraft.value.isNotEmpty()) _symbolDraft.value else _symbolsPreview.value
        return codes.all { m.containsKey(it) }
    }
    fun commitSymbolsForPreview() { _symbolsPreview.value = _symbolDraft.value }
    fun getActivePaletteSwatches(): List<com.appforcross.core.palette.Swatch> =
        paletteRepository?.get(getActivePaletteId())?.colors.orEmpty()
    // --- Экспорт: пост-действия (Preview/Import)
    private val _lastExportUri = MutableStateFlow<Uri?>(null)
    val lastExportUri = _lastExportUri.asStateFlow()
    private val _exports = MutableStateFlow<List<Uri>>(emptyList())
    val exports = _exports.asStateFlow()
    fun registerExport(uri: Uri) {
        _lastExportUri.value = uri
        _exports.value = (listOf(uri) + _exports.value).distinct().take(10)
    }
    fun deleteExport(ctx: Context, uri: Uri): Boolean {
        val ok = DocumentFile.fromSingleUri(ctx, uri)?.delete() == true
        if (ok) {
            if (_lastExportUri.value == uri) _lastExportUri.value = null
            _exports.value = _exports.value.filterNot { it == uri }
        }
        return ok
    }

    fun setSource(image: ImageBitmap, aspect: Float) {
        // Import.applied = исходник; сбрасываем нижние стадии
        appliedImport = image
        appliedPreprocess = null
        appliedSize = null
        appliedPalette = null
        appliedOptions = null
        dirtySize = false; dirtyPalette = false; dirtyOptions = false
        _state.value = _state.value.copy(sourceImage = image, previewImage = image, aspect = aspect)
    }

    fun updatePreprocess(transform: (PreprocessState) -> PreprocessState) {
        _state.value = _state.value.copy(preprocess = transform(_state.value.preprocess))
    }

    fun applyPreprocess() = runStage { st ->
        val base = appliedImport ?: st.sourceImage ?: return@runStage st
        val out = engine.applyPreprocess(base, st.preprocess)
        // фиксируем стадию + инвалидируем последующие
        appliedPreprocess = out
        dirtySize = true; dirtyPalette = true; dirtyOptions = true
        st.copy(previewImage = out)
    }

    fun updateSize(transform: (SizeState) -> SizeState) {
        _state.value = _state.value.copy(size = transform(_state.value.size))
    }

    fun applySize() = runStage { st ->
        // База для Size: Preprocess.applied -> Import.applied
        val base = appliedPreprocess ?: appliedImport ?: st.sourceImage ?: return@runStage st
        val s = st.size

        val srcBmp = base.asAndroidBitmap()
        // Аспект источника (если в стейте невалиден — считаем по картинке)
        val aspect = if (st.aspect > 0f) st.aspect
        else (srcBmp.width.toFloat() / srcBmp.height.coerceAtLeast(1))

        // Рассчитываем целевые размеры в "крестиках"
        var w = s.widthStitches.coerceAtLeast(1)
        var h = s.heightStitches.coerceAtLeast(1)
        when (s.pick) {
            SizePick.BY_WIDTH -> {
                if (s.keepAspect) h = ((w / aspect) + 0.5f).toInt().coerceAtLeast(1)
            }
            SizePick.BY_HEIGHT -> {
                if (s.keepAspect) w = ((h * aspect) + 0.5f).toInt().coerceAtLeast(1)
            }
            SizePick.BY_DPI -> {
                // На этом этапе физическую величину не пересчитываем;
                // при сохранении пропорций обновляем сопряжённую величину.
                if (s.keepAspect) h = ((w / aspect) + 0.5f).toInt().coerceAtLeast(1)
            }
        }

        // Масштабирование: 1 крестик = 1 пиксель результата
        val scaled = Bitmap.createScaledBitmap(srcBmp, w, h, true)
        val out = scaled.asImageBitmap()
        // фиксируем стадию + инвалидируем последующие
        appliedSize = out
        dirtyPalette = true; dirtyOptions = true
        st.copy(previewImage = out, size = s.copy(widthStitches = w, heightStitches = h))
    }

    fun updatePalette(transform: (PaletteState) -> PaletteState) {
        _state.value = _state.value.copy(palette = transform(_state.value.palette))
    }

    fun applyPaletteKMeans() = runStage { st ->
        // База для Palette: Size.applied -> Preprocess.applied -> Import.applied
        val base = appliedSize ?: appliedPreprocess ?: appliedImport ?: st.sourceImage ?: return@runStage st
        val p = st.palette
        android.util.Log.d(
            "Quant",
            "engine=" + engine::class.java.simpleName +
                    " K=" + p.maxColors +
                    " dith=" + p.dithering +
                    " metric=" + p.metric
        )
        val out =
            if (p.maxColors > 0) engine.kMeansQuantize(base, p.maxColors, p.metric, p.dithering)
            else base

        // После квантования считаем статистику ниток по активной палитре
        val limit = (if (p.maxColors > 0) p.maxColors else 32).coerceAtLeast(1)
        val palId = getActivePaletteId()
        val threads = computeThreadStatsAgainstPalette(out, limit, palId)
        _threads.value = threads
// Автоприсвоение символов для новых цветов (существующие не затираем)
        autoAssignSymbolsForThreads(threads)


        fun equalPixels(a: ImageBitmap, b: ImageBitmap): Boolean {
            val ab = a.asAndroidBitmap(); val bb = b.asAndroidBitmap()
            if (ab.width != bb.width || ab.height != bb.height) return false
            val n = ab.width * ab.height
            val pa = IntArray(n); val pb = IntArray(n)
            ab.getPixels(pa, 0, ab.width, 0, 0, ab.width, ab.height)
            bb.getPixels(pb, 0, bb.width, 0, 0, bb.width, bb.height)
            return pa.contentEquals(pb)
        }
        android.util.Log.d("Quant", "pixelsEqual=" + equalPixels(st.previewImage ?: st.sourceImage!!, out))

        val before = uniqueColors(st.previewImage ?: st.sourceImage!!)
        val after  = uniqueColors(out)
        android.util.Log.d("Quant", "before=" + before + " after=" + after)
        // фиксируем стадию + инвалидируем последующие
        appliedPalette = out
        dirtyOptions = true
        // Возвращаем новый стейт через runStage
        st.copy(previewImage = out)
           }

    fun updateOptions(transform: (OptionsState) -> OptionsState) {
        _state.value = _state.value.copy(options = transform(_state.value.options))
    }

    fun applyOptions() = runStage { st ->
        // База для Options: Palette.applied -> Size.applied -> Preprocess.applied -> Import.applied
        val base = appliedPalette ?: appliedSize ?: appliedPreprocess ?: appliedImport ?: st.sourceImage ?: return@runStage st
        val out = engine.applyOptions(base, st.options, st.palette.metric)
        appliedOptions = out
        st.copy(previewImage = out)
    }

    private fun uniqueColors(bmp: ImageBitmap): Int {
        val ab = bmp.asAndroidBitmap()
        val n = ab.width * ab.height
        val buf = IntArray(n)
        ab.getPixels(buf, 0, ab.width, 0, 0, ab.width, ab.height)
        return buf.toHashSet().size
    }

    // Подсчёт «ниток» относительно активной палитры (fallback — топ-N по hex)
    private fun computeThreadStatsAgainstPalette(
        bmp: androidx.compose.ui.graphics.ImageBitmap,
        limit: Int,
        paletteId: String
    ): List<ThreadItem> {
        val ab = bmp.asAndroidBitmap()
        val w = ab.width
        val h = ab.height
        val total = (w * h).coerceAtLeast(1)
        val px = IntArray(total)
        ab.getPixels(px, 0, w, 0, 0, w, h)

        val pal = paletteRepository?.get(paletteId)
        if (pal == null || pal.colors.isEmpty()) {
            // Fallback: топ-N по #RRGGBB
            val counts = HashMap<Int, Int>(1024)
            for (c in px) {
                val rgb = c and 0x00FFFFFF
                counts[rgb] = (counts[rgb] ?: 0) + 1
            }
            return counts.entries
                .sortedByDescending { it.value }
                .take(limit.coerceAtLeast(1))
                .map { (rgb, cnt) ->
                val argb = 0xFF000000.toInt() or rgb
                val hex = String.format("#%06X", rgb)
                ThreadItem(
                    code = hex,
                    name = hex,
                    argb = argb,
                    percent = (cnt * 100) / total,
                    count = cnt
                )
            }
        }
        val colors = pal.colors
        val n = colors.size
        val counts = IntArray(n)
        val swR = IntArray(n)
        val swG = IntArray(n)
        val swB = IntArray(n)
        for (i in 0 until n) {
            val a = colors[i].argb
            swR[i] = (a shr 16) and 0xFF
            swG[i] = (a shr 8) and 0xFF
            swB[i] = a and 0xFF
        }
        for (c in px) {
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            var best = 0
            var bestD = Int.MAX_VALUE
            var i = 0
            while (i < n) {
                val dr = r - swR[i]
                val dg = g - swG[i]
                val db = b - swB[i]
                val d = dr*dr + dg*dg + db*db
                if (d < bestD) { bestD = d; best = i }
                i++
            }
            counts[best]++
        }
        return counts
            .mapIndexed { i, cnt -> i to cnt }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(limit.coerceAtLeast(1))
            .map { (i, cnt) ->
            val sw = colors[i]
            ThreadItem(
                code = sw.code,
                name = sw.name,
                argb = sw.argb,
                percent = (cnt * 100) / total,
                count = cnt
            )
        }
    }

    private fun runStage(block: (EditorState) -> EditorState) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isBusy = true, error = null)
            try {
                val next = withContext(Dispatchers.Default) { block(_state.value) }
                _state.value = next.copy(isBusy = false)
            } catch (t: Throwable) {
                _state.value = _state.value.copy(isBusy = false, error = t.message)
            }
        }
    }
}